function showText() {
    document.getElementById('container').innerHTML = 'Welcome to Grazitti Skillstone for learning';
}

showText();