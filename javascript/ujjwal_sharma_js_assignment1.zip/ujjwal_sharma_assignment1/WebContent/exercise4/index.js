function department() {
    let dep = 'Mechanical';
    if(dep= 'Mechanical') {
        document.getElementById('container').innerHTML= `Chosen ${dep} department`
    }
    else if(dep= 'Electrical'){
        document.getElementById('container').innerHTML= `Chosen ${dep} department`
    }
    else{
        document.getElementById('container').innerHTML= `Chosen ${dep} department`
    }
}

department();