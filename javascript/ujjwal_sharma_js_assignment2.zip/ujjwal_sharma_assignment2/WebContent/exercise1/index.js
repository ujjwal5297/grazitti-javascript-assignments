function displayName() {
    document.getElementById('container').innerHTML='Employee name is Karthik';
}

document.getElementById('button').addEventListener('click', displayName);