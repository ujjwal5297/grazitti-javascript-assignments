function myfunction() {
    alert("Welcomes you all for javascript learning")
}

// document.getElementsByTagName('button')[0].addEventListener('click',myfunction())